from fastapi import FastAPI, UploadFile, File, HTTPException
from confluent_kafka import Producer
import boto3
import json
import uuid
import os

app = FastAPI()

# --- CONFIGURACIÓN DINÁMICA ---
# Si la variable de entorno no existe, usa los nombres de los servicios de Docker
MINIO_URL = os.getenv("MINIO_ENDPOINT", "http://minio:9000")
KAFKA_SERVER = os.getenv("KAFKA_SERVER", "kafka:9092")

# Cliente MinIO
s3_client = boto3.client(
    's3',
    endpoint_url=MINIO_URL,
    aws_access_key_id='admin',
    aws_secret_access_key='password123'
)

# Productor Kafka
# Cambia solo la configuración del productor
producer_conf = {
    'bootstrap.servers': KAFKA_SERVER,
    'socket.timeout.ms': 10000,
    'reconnect.backoff.ms': 500,
    'reconnect.backoff.max.ms': 10000
}
producer = Producer(producer_conf)

@app.post("/upload")
async def upload_image(file: UploadFile = File(...)):
    job_id = str(uuid.uuid4())
    file_name = f"{job_id}_{file.filename}"

    try:
        # 1. Subir a MinIO
        # Importante: El bucket 'images-raw' debe existir en MinIO
        s3_client.upload_fileobj(file.file, "images-raw", file_name)

        # 2. Notificar a Kafka
        event = {
            "job_id": job_id,
            "image_url": file_name,
            "status": "RAW"
        }

        # Publicamos en el topic 'images.raw'
        producer.produce('images.raw', value=json.dumps(event).encode('utf-8'))
        producer.flush() # Forzamos el envío del mensaje

        return {"message": "Imagen recibida y evento enviado", "job_id": job_id}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
