import cv2
import numpy as np
import boto3
from confluent_kafka import Consumer, Producer
import json
import os
from deepface import DeepFace

MINIO_URL = os.getenv("MINIO_ENDPOINT", "http://minio:9000")
KAFKA_SERVER = os.getenv("KAFKA_SERVER", "kafka:9092")

s3_client = boto3.client('s3', endpoint_url=MINIO_URL, aws_access_key_id='admin', aws_secret_access_key='password123')
consumer = Consumer({'bootstrap.servers': KAFKA_SERVER, 'group.id': 'age-group', 'auto.offset.reset': 'earliest'})
producer = Producer({'bootstrap.servers': KAFKA_SERVER})
consumer.subscribe(['cmd.age_detection'])

print("--- [AGE SERVICE] Esperando coordenadas ---")

while True:
    msg = consumer.poll(1.0)
    if msg is None: continue
    
    # --- ESCUDO ANTI-ERROR JSON ---
    try:
        val = msg.value()
        if not val: continue
        data = json.loads(val.decode('utf-8'))
    except Exception:
        continue
    # ------------------------------

    job_id = data['job_id']
    image_name = data['image_url']
    faces = data.get('faces', [])

    obj = s3_client.get_object(Bucket='images-raw', Key=image_name)
    img = cv2.imdecode(np.frombuffer(obj['Body'].read(), np.uint8), cv2.IMREAD_COLOR)

    results = []
    for face in faces:
        x, y, w, h = face['box']
        face_img = img[max(0, y-10):y+h+10, max(0, x-10):x+w+10]
        try:
            analysis = DeepFace.analyze(face_img, actions=['age'], enforce_detection=False)
            age = analysis[0]['age']
            results.append({"box": [int(x), int(y), int(w), int(h)], "age": int(age), "is_minor": age < 18})
        except:
            continue

    print(f"===> [AGE] Job {job_id}: {len(results)} rostros analizados.")

    output = {"job_id": job_id, "image_url": image_name, "results": results}
    producer.produce('evt.age_detection.completed', value=json.dumps(output).encode('utf-8'))
    producer.flush()