from confluent_kafka import Consumer, Producer
import json
import os
import time

KAFKA_SERVER = os.getenv("KAFKA_SERVER", "kafka:9092")

# Configuración del Consumidor
conf = {
    'bootstrap.servers': KAFKA_SERVER,
    'group.id': 'orchestrator-group',
    'auto.offset.reset': 'earliest'
}

consumer = Consumer(conf)
producer = Producer({'bootstrap.servers': KAFKA_SERVER})

consumer.subscribe(['images.raw'])

print("--- Orquestador iniciado y escuchando 'images.raw' ---")

try:
    while True:
        msg = consumer.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            print(f"Error de Kafka: {msg.error()}")
            continue

        # 1. Recibir el evento del API
        data = json.loads(msg.value().decode('utf-8'))
        job_id = data['job_id']
        image_url = data['image_url']

        print(f"\n===> [ORQUESTADOR] ¡Imagen detectada! Job ID: {job_id}")

        # 2. Decidir el siguiente paso: Detección de Rostros
        command = {
            "job_id": job_id,
            "image_url": image_url,
            "status": "DETECTING_FACES"
        }

        # 3. Publicar comando para el siguiente microservicio
        producer.produce('cmd.face_detection', value=json.dumps(command).encode('utf-8'))
        producer.flush()

        print(f"      Comando 'cmd.face_detection' enviado para {image_url}")

except KeyboardInterrupt:
    print("Orquestador detenido.")
finally:
    consumer.close()
