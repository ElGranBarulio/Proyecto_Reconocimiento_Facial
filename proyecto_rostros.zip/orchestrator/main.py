import psycopg2
from confluent_kafka import Consumer, Producer
import json
import os
import time
from datetime import datetime

# Configuración DB
DB_CONF = {
    "host": os.getenv("DB_HOST", "db"),
    "database": os.getenv("DB_NAME", "db_rostros"),
    "user": os.getenv("DB_USER", "user_rostros"),
    "password": os.getenv("DB_PASS", "password_rostros")
}

def init_db():
    while True:
        try:
            conn = psycopg2.connect(**DB_CONF)
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS Solicitud (
                    Id_Solicitud SERIAL PRIMARY KEY,
                    GUID_Solicitud VARCHAR(255),
                    Id_Fichero VARCHAR(255),
                    Inicio_Solicitud TIMESTAMP,
                    Fin_Solicitud TIMESTAMP,
                    Inicio_Deteccion_Caras TIMESTAMP,
                    Fin_Deteccion_Caras TIMESTAMP,
                    Estado VARCHAR(50)
                );
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS Imagenes (
                    Id_Imagen SERIAL PRIMARY KEY,
                    GUID_Solicitud VARCHAR(255),
                    Inicio_Edad TIMESTAMP,
                    Fin_edad TIMESTAMP,
                    Estado VARCHAR(50)
                );
            """)
            conn.commit()
            cur.close()
            conn.close()
            print("--- Base de datos conectada y tablas listas ---")
            break
        except Exception as e:
            print(f"Esperando a la base de datos... {e}")
            time.sleep(2)

init_db()
KAFKA_SERVER = os.getenv("KAFKA_SERVER", "kafka:9092")
consumer = Consumer({'bootstrap.servers': KAFKA_SERVER, 'group.id': 'orch-group', 'auto.offset.reset': 'earliest'})
producer = Producer({'bootstrap.servers': KAFKA_SERVER})
consumer.subscribe(['images.raw', 'evt.face_detection.completed', 'evt.age_detection.completed'])

print("--- Orquestador escuchando eventos ---")

while True:
    msg = consumer.poll(1.0)
    if msg is None: continue
    if msg.error():
        print(f"Error Kafka: {msg.error()}")
        continue
    
    # --- ESCUDO ANTI-ERROR JSON ---
    try:
        val = msg.value()
        if not val: continue
        data = json.loads(val.decode('utf-8'))
        job_id = data.get('job_id')
        if not job_id: continue
    except Exception as e:
        print(f"Error procesando JSON: {e}")
        continue
    # ------------------------------

    topic = msg.topic()
    conn = psycopg2.connect(**DB_CONF)
    cur = conn.cursor()

    if topic == 'images.raw':
        print(f"===> [ORCH] Nueva solicitud: {job_id}")
        cur.execute(
            "INSERT INTO Solicitud (GUID_Solicitud, Id_Fichero, Inicio_Solicitud, Estado) VALUES (%s, %s, %s, %s)",
            (job_id, data['image_url'], datetime.now(), 'RAW')
        )
        producer.produce('cmd.face_detection', value=json.dumps(data).encode('utf-8'))
        
    elif topic == 'evt.face_detection.completed':
        print(f"===> [ORCH] Caras detectadas. Enviando a Edad: {job_id}")
        cur.execute(
            "UPDATE Solicitud SET Fin_Deteccion_Caras = %s, Estado = %s WHERE GUID_Solicitud = %s",
            (datetime.now(), 'FACES_DETECTED', job_id)
        )
        producer.produce('cmd.age_detection', value=json.dumps(data).encode('utf-8'))

    elif topic == 'evt.age_detection.completed':
        print(f"===> [ORCH] Edad estimada para {job_id}. Enviando a Pixelado.")
        cur.execute("UPDATE Solicitud SET Estado = %s WHERE GUID_Solicitud = %s", ('AGE_ESTIMATED', job_id))
        # Descomentar cuando el pixelador esté listo:
        # producer.produce('cmd.pixelation', value=json.dumps(data).encode('utf-8'))

    conn.commit()
    cur.close()
    conn.close()
    producer.flush()