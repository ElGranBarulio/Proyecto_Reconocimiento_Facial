import cv2
import numpy as np
import boto3
from confluent_kafka import Consumer, Producer
import json
import os

# Configuración
MINIO_URL = os.getenv("MINIO_ENDPOINT", "http://minio:9000")
KAFKA_SERVER = os.getenv("KAFKA_SERVER", "kafka:9092")

s3_client = boto3.client('s3', endpoint_url=MINIO_URL, aws_access_key_id='admin', aws_secret_access_key='password123')
consumer = Consumer({'bootstrap.servers': KAFKA_SERVER, 'group.id': 'detect-group', 'auto.offset.reset': 'earliest'})
producer = Producer({'bootstrap.servers': KAFKA_SERVER})

# Cargar modelo de rostros pre-entrenado de OpenCV
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

consumer.subscribe(['cmd.face_detection'])
print("--- Servicio de Detección de Rostros listo ---")

while True:
    msg = consumer.poll(1.0)
    if msg is None: continue

    data = json.loads(msg.value().decode('utf-8'))
    job_id = data['job_id']
    image_name = data['image_url']

    # 1. Descargar imagen de MinIO
    obj = s3_client.get_object(Bucket='images-raw', Key=image_name)
    img_data = obj['Body'].read()
    nparr = np.frombuffer(img_data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    # 2. Detectar rostros
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    # Convertir coordenadas a lista para JSON
    face_list = []
    for (x, y, w, h) in faces:
        face_list.append({"box": [int(x), int(y), int(w), int(h)]})

    print(f"===> [DETECTION] Job {job_id}: Detectados {len(face_list)} rostros")

    # 3. Notificar finalización
    result = {
        "job_id": job_id,
        "image_url": image_name,
        "faces": face_list,
        "status": "FACES_DETECTED"
    }
    producer.produce('evt.face_detection.completed', value=json.dumps(result).encode('utf-8'))
    producer.flush()
